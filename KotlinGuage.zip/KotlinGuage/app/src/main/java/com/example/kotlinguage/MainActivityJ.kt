package com.example.kotlinguage

import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import androidx.appcompat.app.AppCompatActivity

class MainActivityJ : AppCompatActivity() {
    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val gauge1: Gauge = findViewById(R.id.gauge1)
        val gauge2: Gauge = findViewById(R.id.gauge2)
        val gauge3: Gauge = findViewById(R.id.gauge3)
        val gauge4: Gauge = findViewById(R.id.gauge4)

        /*
        gauge1.setMaxValue(800);
        gauge1.setMinValue(0);
        gauge1.setTotalNicks(100);
        gauge1.setValuePerNick(10);
        gauge1.setMajorNickInterval(10);
        gauge1.setUpperTextSize(100);
        gauge1.setLowerTextSize(48);
        */gauge1.moveToValue(800f)
        val thread = HandlerThread("GaugeDemoThread")
        thread.start()
        val handler: Handler = Handler(thread.getLooper())
        handler.postDelayed({ gauge1.moveToValue(300f) }, 2800)
        handler.postDelayed({ gauge1.moveToValue(550f) }, 5600)
        val gauge3Thread = HandlerThread("Gauge3DemoThread")
        gauge3Thread.start()
        val gauge3Handler: Handler = Handler(gauge3Thread.getLooper())
        gauge3Handler.post {
            var x = 0f
            while (x <= 6) {
                val value = Math.atan(x.toDouble()).toFloat() * 20
                gauge3.moveToValue(value)
                try {
                    Thread.sleep(100)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
                x += .1f
            }
        }
        gauge4.setValue(333f)
    }
}
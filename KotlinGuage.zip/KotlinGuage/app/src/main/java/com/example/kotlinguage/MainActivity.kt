package com.example.kotlinguage

import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import android.widget.Toolbar
import androidx.viewbinding.ViewBinding
import com.example.kotlinguage.databinding.ActivityMainBinding

private val ViewBinding.fab: Any
    get() { return 0 }
//private val ViewBinding.toolbar: Toolbar?
//    get() { return 0 }

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val gauge1: Gauge = findViewById(R.id.gauge1)
        val gauge2: Gauge = findViewById(R.id.gauge2)
        val gauge3: Gauge = findViewById(R.id.gauge3)
        val gauge4: Gauge = findViewById(R.id.gauge4)


        gauge1.setMaxValue(800F);
        gauge1.setMinValue(0F);
        gauge1.setTotalNicks(100);
        gauge1.setValuePerNick(10F);
        gauge1.setMajorNickInterval(10);
        gauge1.setUpperTextSize(100F);
        gauge1.setLowerTextSize(48F);
        gauge1.moveToValue(800f)
        val thread = HandlerThread("GaugeDemoThread")
        thread.start()
        val handler: Handler = Handler(thread.getLooper())
        handler.postDelayed({ gauge1.moveToValue(300f) }, 2800)
        handler.postDelayed({ gauge1.moveToValue(550f) }, 5600)
        val gauge3Thread = HandlerThread("Gauge3DemoThread")
        gauge3Thread.start()
        val gauge3Handler: Handler = Handler(gauge3Thread.getLooper())
        gauge3Handler.post {
            var x = 0f
            while (x <= 6) {
                val value = Math.atan(x.toDouble()).toFloat() * 20
                gauge3.moveToValue(value)
                try {
                    Thread.sleep(100)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
                x += .1f
            }
        }
        gauge4.setValue(333f)
//        setSupportActionBar(binding.toolbar)
/*
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)
*/
/*binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
*/
/*        }
        override fun onCreateOptionsMenu(menu: Menu): Boolean {
            // Inflate the menu; this adds items to the action bar if it is present.
            menuInflater.inflate(R.menu.menu_main, menu)
            return true
        }
*/
/*       override fun onOptionsItemSelected(item: MenuItem): Boolean {
            // Handle action bar item clicks here. The action bar will
            // automatically handle clicks on the Home/Up button, so long
            // as you specify a parent activity in AndroidManifest.xml.
            return when (item.itemId) {
                R.id.action_settings -> true
                else -> super.onOptionsItemSelected(item)
            }
*/
        }
/*
        override fun onSupportNavigateUp(): Boolean {
            val navController = findNavController(R.id.nav_host_fragment_content_main)
            return navController.navigateUp(appBarConfiguration)
                    || super.onSupportNavigateUp()
        }
*/
}